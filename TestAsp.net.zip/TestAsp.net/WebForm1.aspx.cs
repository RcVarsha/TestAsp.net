﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestAsp.net
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string mainconn = ConfigurationManager.ConnectionStrings["Myconnection"].ConnectionString;
            SqlConnection sqlConn = new SqlConnection(mainconn);
            string sqlquery = "Insert into [dbo].[Position] (cPositionCode,vDescription ,iBudgetedStrength,siYear,iCurrentStrength) values (@cPositionCode,@iBudgetedStrength, @siYear,@iCurrentStrength)";
            SqlCommand sqlcomm = new SqlCommand(sqlquery, sqlConn);
            sqlcomm.Parameters.AddWithValue("@cPositionCode", TxtPositioncode.Text);
            sqlcomm.Parameters.AddWithValue("@vDescription", TxtDescription);
            sqlcomm.Parameters.AddWithValue("@iBudgetedStrength", TextBox2.Text);
            // sqlcomm.Parameters.AddWithValue("@siYear", TxtYear.Text);
            sqlcomm.Parameters.AddWithValue("@iCurrentStrength", TextBox4.Text);





            sqlConn.Open();
            sqlcomm.ExecuteNonQuery();
            sqlConn.Close();
        }
    }
}

       